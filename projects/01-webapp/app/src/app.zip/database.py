import os
from sqlalchemy import Column, Integer, String, Boolean
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy.pool import NullPool
from sqlalchemy import create_engine


DB_CONNECTION = os.getenv("db_connection")

class Database:
    def __init__(self, db_conn):
        self.engine = create_engine(url=db_conn,
                                    poolclass=NullPool,
                                    connect_args={"timeout": 15})
        self.session = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)


    def get_db(self):
        try:
            db = self.session()
            yield db
        finally:
            db.close()

    @property
    def conn(self):
        return self.engine.connect()

azdb = Database(DB_CONNECTION)
Base = declarative_base

class Task(Base):
    __tablename__ = "task"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255),nullable=False )
    done = Column(Boolean, default=False, nullable=False)