from fastapi import FastAPI, Depends
from database import azdb, Base, Task
from pydantic import BaseModel
from typing import List
from sqlalchemy.orm import Session
import uvicorn

app = FastAPI(
    title="Todo simple app",
    description="A simple todo app using FastAPI and SQLAlchemy",
    version="0.1.0",
)

Base.metadata.create_all(bind=azdb.engine)

class TaskCreate(BaseModel):
    title: str
    done: bool = False

class TaskOut(BaseModel):
    id: int
    title: str

    class Config:
        orm_mode = True

@app.get("/task", response_model=List[TaskOut])
def get_task(db: Session = Depends(azdb.get_db)):
    return db.query(Task).all()

@app.post("/task", response_model=TaskOut)
def create_task(task: TaskCreate, db: Session = Depends(azdb.get_db)):
    new_task = Task(title= task.title, done = task.done)
    db.add(new_task)
    db.commit()
    db.refresh(new_task)
    return new_task



if __name__ == '__main__':
    uvicorn.run('main:app', host='0.0.0.0', port=8000)